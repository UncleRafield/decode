let player1Code = '';
let player2Code = '';
let currentPlayer = 1;
let gameActive = false;

function startGame() {
  player1Code = document.getElementById("player1Code").value.trim();
  player2Code = document.getElementById("player2Code").value.trim();

  // Validate that both codes are 4 digits and numeric
  if (isValidCode(player1Code) && isValidCode(player2Code)) {
    gameActive = true;
    document.getElementById("setup").style.display = "none";
    document.getElementById("gameBoard").style.display = "block";
    document.getElementById("feedback").innerHTML = "";
    document.getElementById("result").innerHTML = "";
    document.getElementById("restartButton").style.display = "none"; // Hide restart button
    document.getElementById("currentPlayer").innerText = `Player ${currentPlayer}`;
  } else {
    alert("Please enter a valid 4-digit numeric code for both players.");
  }
}

// Validate if code is exactly 4 digits and numeric
function isValidCode(code) {
  return /^\d{4}$/.test(code); // Checks if code is exactly 4 digits
}

function makeGuess() {
  if (!gameActive) return;
  
  const guess = document.getElementById("guessInput").value.trim();
  if (!isValidCode(guess)) {
    alert("Please enter a valid 4-digit numeric guess.");
    return;
  }
  
  let feedback = checkGuess(currentPlayer === 1 ? player2Code : player1Code, guess);
  document.getElementById("feedback").innerHTML = `Player ${currentPlayer} guessed ${guess}: ${feedback}`;

  if (feedback === "4 correct!") {
    document.getElementById("result").innerHTML = `🎉 Player ${currentPlayer} wins! 🎉`;
    document.getElementById("restartButton").style.display = "block"; // Show restart button
    gameActive = false;
    return;
  }
  
  // Switch players
  currentPlayer = currentPlayer === 1 ? 2 : 1;
  document.getElementById("currentPlayer").innerText = `Player ${currentPlayer}`;
  document.getElementById("guessInput").value = "";
}

function checkGuess(secretCode, guess) {
  let correctCount = 0;
  for (let i = 0; i < 4; i++) {
    if (secretCode[i] === guess[i]) {
      correctCount++;
    }
  }
  return `${correctCount} correct!`;
}

function restartGame() {
  // Reset game state
  player1Code = '';
  player2Code = '';
  currentPlayer = 1;
  gameActive = false;

  // Hide game board and result, show setup screen
  document.getElementById("setup").style.display = "block";
  document.getElementById("gameBoard").style.display = "none";
  document.getElementById("restartButton").style.display = "none";
  document.getElementById("result").innerHTML = "";
  document.getElementById("feedback").innerHTML = "";

  // Clear input fields
  document.getElementById("player1Code").value = '';
  document.getElementById("player2Code").value = '';
  document.getElementById("guessInput").value = '';
}
